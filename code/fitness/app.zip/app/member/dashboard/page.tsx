// app/member/view/dashboard/page.js
"use client";

import { Card, Row, Col, Statistic, Button, Typography, Badge, Popover, List, Spin, message, Progress, Tag } from "antd";
import { useState, useEffect } from "react";
import Link from "next/link";
import './styles.css';
import { 
  ClockCircleOutlined, 
  HistoryOutlined, 
  CalendarOutlined, 
  BellOutlined,
  UserOutlined,
  LogoutOutlined,
  TrophyOutlined,
  CheckOutlined,
  EditOutlined,
  EnvironmentOutlined
} from "@ant-design/icons";
import { collection, query, where, getDocs, Timestamp, onSnapshot, orderBy, addDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useAuth } from '@/lib/auth';
import { useRouter } from 'next/navigation';
import { doc, updateDoc } from 'firebase/firestore';
import { withAuth } from '@/app/components/withAuth';
import {
  containerStyle,
  contentStyle,
  headerStyle,
  avatarContainerStyle,
  avatarStyle,
  titleStyle,
  welcomeTextStyle,
  headerActionsStyle,
  bellButtonStyle,
  logoutButtonStyle,
  statisticTitleStyle,
  statisticIconStyle,
  statisticValueStyle,
  statisticDescStyle,
  dotStyle,
  navCardIconStyle,
  navCardTitleStyle,
  navCardValueStyle,
  navCardDescStyle,
  navCardDotStyle
} from './styles';
import FitnessMap from '@/app/components/FitnessMap';

const { Title, Text } = Typography;

interface DashboardStats {
  totalTrainingMinutes: number;
  upcomingAppointments: number;
  completedTrainings: number;
  unreadNotifications: number;
}

interface TrainingRecord {
  id: string;
  duration: number;
  email: string;
  sessionDate: Timestamp;
  status: 'completed' | 'cancelled' | 'pending';
  session?: string;
  courseType?: string;
}

interface CourseProgress {
  courseType: string;
  completedSessions: number;
  totalSessionsRequired: number;
  progressPercentage: number;
}

interface Notification {
  id: string;
  title: string;
  description: string;
  date: string;
  type: 'appointment' | 'training' | 'system';
  read: boolean;
}

// 添加一个辅助函数来编码邮箱地址
const encodeEmail = (email: string) => {
  return email.replace(/[.@]/g, '_');
};

const DashboardPage = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalTrainingMinutes: 0,
    upcomingAppointments: 0,
    completedTrainings: 0,
    unreadNotifications: 0
  });
  const [courseProgress, setCourseProgress] = useState<Record<string, CourseProgress>>({});
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const { user, memberData, signOut, loading: authLoading } = useAuth();
  const router = useRouter();

  const calculateCourseProgress = (records: TrainingRecord[]) => {
    try {
      // Filter out records with missing session type
      const validRecords = records.filter(record => record.session);
      console.log(`Calculating progress for ${validRecords.length} valid records`);
      
      const courseGroups = validRecords.reduce<Record<string, TrainingRecord[]>>((acc, record) => {
        try {
          const session = record.session;
          if (!session) return acc;
          
          if (!acc[session]) {
            acc[session] = [];
          }
            
          if (record.status === 'completed') {
            acc[session].push(record);
          }
          return acc;
        } catch (error) {
          console.error("Error processing record for course progress:", error, record);
          return acc;
        }
      }, {});
      
      const progress: Record<string, CourseProgress> = {};
      for (const [session, courseRecords] of Object.entries(courseGroups)) {
        const totalSessionsRequired = 10;
        const completedSessions = courseRecords.length;
        const progressPercentage = Math.min(Math.round((completedSessions / totalSessionsRequired) * 100), 100);
        
        progress[session] = {
          courseType: session,
          completedSessions,
          totalSessionsRequired,
          progressPercentage
        };
      }
      
      console.log("Course progress calculated:", progress);
      setCourseProgress(progress);
    } catch (error) {
      console.error("Error calculating course progress:", error);
      setCourseProgress({});
    }
  };

  // 监听预约变化
  useEffect(() => {
    if (!user || !memberData) return;

    const now = new Date();
    const appointmentQuery = query(
      collection(db, 'appointments'),
      where('memberEmail', '==', memberData.email),
      where('status', '==', 'scheduled')
    );

    // 设置实时监听
    const unsubscribeAppointments = onSnapshot(appointmentQuery, (snapshot) => {
      const upcomingAppointments = snapshot.docs.filter(doc => {
        const data = doc.data();
        const appointmentDate = data.date;
        const appointmentEndTime = data.timeEnd;
        
        if (appointmentDate instanceof Timestamp) {
          const appointmentDateTime = appointmentDate.toDate();
          // 设置预约结束时间
          const [hours, minutes] = appointmentEndTime.split(':').map(Number);
          appointmentDateTime.setHours(hours, minutes, 0, 0);
          return appointmentDateTime > now;
        }
        return false;
      }).length;

      setStats(prev => ({
        ...prev,
        upcomingAppointments
      }));
    });

    return () => {
      unsubscribeAppointments();
    };
  }, [user, memberData]);

  // 监听训练记录变化
  useEffect(() => {
    if (!user || !memberData) return;

    const trainingQuery = query(
      collection(db, 'trainingRecords'),
      where('email', '==', memberData.email),
      where('status', '==', 'completed')
    );

    // 设置实时监听
    const unsubscribeTraining = onSnapshot(trainingQuery, (snapshot) => {
      const completedTrainings = snapshot.docs.length;
      const totalMinutes = snapshot.docs.reduce(
        (total, doc) => total + (doc.data().duration || 0), 
        0
      );

      const records = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as TrainingRecord[];

      calculateCourseProgress(records);

      setStats(prev => ({
        ...prev,
        totalTrainingMinutes: totalMinutes,
        completedTrainings
      }));
    });

    return () => {
      unsubscribeTraining();
    };
  }, [user, memberData]);

  const markAsRead = async (notificationId: string) => {
    if (!memberData?.email) return;

    try {
      const notificationRef = doc(db, 'notifications', notificationId);
      await updateDoc(notificationRef, { read: true });
      
      // 本地状态会通过 onSnapshot 自动更新
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  // 监听通知变化
  useEffect(() => {
    if (!memberData?.email) return;

    const notificationsQuery = query(
      collection(db, 'notifications'),
      where('email', '==', memberData.email),
      where('read', '==', false),
      orderBy('createdAt', 'desc')
    );
    
    // 设置实时监听
    const unsubscribeNotifications = onSnapshot(notificationsQuery, (snapshot) => {
      const notificationsList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Notification[];
      
      setNotifications(notificationsList);
      setStats(prev => ({
        ...prev,
        unreadNotifications: notificationsList.length
      }));

      // 如果有新通知，显示提醒
      snapshot.docChanges().forEach((change) => {
        if (change.type === 'added') {
          const notification = change.doc.data();
          message.open({
            type: 'info',
            content: (
              <div>
                <div style={{ fontWeight: 'bold' }}>{notification.title}</div>
                <div>{notification.description}</div>
              </div>
            ),
            duration: 5,
            icon: <BellOutlined style={{ color: '#1890ff' }} />
          });
        }
      });
    });

    return () => {
      unsubscribeNotifications();
    };
  }, [memberData?.email]);

  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        router.push('/home');
        return;
      }
      if (!memberData) {
        setLoading(true);
      } else {
        setLoading(false);
      }
    }
  }, [user, memberData, authLoading]);

  const handleLogout = async () => {
    try {
      await signOut();
      router.push('/login');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'appointment':
        return '📅';
      case 'training':
        return '💪';
      case 'system':
        return '🔔';
      default:
        return '📌';
    }
  };

  const notificationContent = (
    <div style={{ 
      width: 350, 
      maxHeight: 450, 
      overflow: 'auto',
      padding: '8px',
      borderRadius: '8px'
    }}>
      {loading ? (
        <div style={{ 
          textAlign: 'center', 
          padding: '40px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '12px'
        }}>
          <Spin size="large" />
          <Text type="secondary">Loading notifications...</Text>
        </div>
      ) : notifications.length > 0 ? (
        <List
          dataSource={notifications}
          renderItem={(item) => (
            <List.Item
              className={`notification-item ${item.read ? 'notification-item-read' : 'notification-item-unread'}`}
            >
              <div style={{ width: '100%' }}>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between', 
                  alignItems: 'center', 
                  marginBottom: '8px' 
                }}>
                  <div style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '12px' 
                  }}>
                    <span style={{ 
                      fontSize: '20px',
                      filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.1))'
                    }}>
                      {getNotificationIcon(item.type)}
                    </span>
                    <Text strong style={{ fontSize: '15px' }}>{item.title}</Text>
                  </div>
                  {!item.read && (
                    <Button
                      type="text"
                      size="small"
                      icon={<CheckOutlined />}
                      onClick={() => markAsRead(item.id)}
                      style={{
                        color: '#1890ff',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        padding: '4px 12px',
                        borderRadius: '15px',
                        transition: 'all 0.3s ease'
                      }}
                    >
                      Mark as Read
                    </Button>
                  )}
                </div>
                <Text type="secondary" style={{ 
                  fontSize: '13px',
                  display: 'block',
                  marginBottom: '6px'
                }}>
                  {new Date(item.date).toLocaleString()}
                </Text>
                <div style={{ marginTop: '4px' }}>
                  <Text style={{ fontSize: '14px', lineHeight: '1.5' }}>
                    {item.description}
                  </Text>
                </div>
              </div>
            </List.Item>
          )}
        />
      ) : (
        <div style={{ 
          textAlign: 'center', 
          padding: '40px', 
          color: '#666',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '12px' 
        }}>
          <BellOutlined style={{ fontSize: '24px', opacity: 0.5 }} />
          <Text type="secondary">No notifications</Text>
        </div>
      )}
    </div>
  );

  const handleEditProfile = () => {
    router.push('/member/profile');
  };

  if (loading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh' 
      }}>
        <Spin size="large" />
      </div>
    );
  }

  return (
    <div style={containerStyle}>
      <div style={contentStyle}>
        <div style={headerStyle}>
          <div style={avatarContainerStyle}>
            <div style={avatarStyle}>
              <UserOutlined style={{ fontSize: "28px", color: "#fff" }} />
            </div>
            <div>
              <Title level={2} style={titleStyle}>
                Member Dashboard
              </Title>
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                <span style={welcomeTextStyle}>
                  Welcome back, {memberData?.name || 'Member'}!
                </span>
                <Button 
                  type="link" 
                  icon={<EditOutlined />} 
                  onClick={handleEditProfile}
                  style={{ padding: 0, height: 'auto' }}
                >
                  Edit Profile
                </Button>
              </div>
            </div>
          </div>
          <div style={headerActionsStyle}>
            <Popover
              content={notificationContent}
              title={
                <div style={{
                  padding: '8px 4px',
                  fontSize: '16px',
                  fontWeight: 600,
                  borderBottom: '1px solid #f0f0f0'
                }}>
                  Notifications
                </div>
              }
              trigger="click"
              placement="bottomRight"
              overlayStyle={{ 
                width: 350,
                padding: 0
              }}
              overlayInnerStyle={{
                borderRadius: '12px',
                boxShadow: '0 6px 16px rgba(0,0,0,0.08)'
              }}
            >
              <Badge 
                count={notifications.filter(n => !n.read).length} 
                offset={[-2, 2]}
                style={{
                  backgroundColor: '#ff4d4f'
                }}
              >
                <Button
                  type="text"
                  icon={<BellOutlined style={{ 
                    fontSize: '22px',
                    color: 'rgba(0, 0, 0, 0.65)'
                  }} />}
                  className="notification-button"
                  style={bellButtonStyle}
                />
              </Badge>
            </Popover>
            <Button 
              type="primary" 
              danger 
              icon={<LogoutOutlined />}
              onClick={handleLogout}
              size="large"
              style={logoutButtonStyle}
            >
              Logout
            </Button>
          </div>
        </div>
        
        {/* Statistics cards */}
        <Row gutter={[24, 24]} style={{ marginBottom: "32px" }}>
          <Col xs={24} sm={8}>
            <Card 
              hoverable 
              className="stat-card"
            >
              <Statistic
                title={
                  <div style={statisticTitleStyle("#1890ff")}>
                    <ClockCircleOutlined style={statisticIconStyle("rgba(24,144,255,0.1)")} />
                    Total Training Hours
                  </div>
                }
                value={Math.round(stats.totalTrainingMinutes / 60 * 10) / 10}
                suffix="hrs"
                valueStyle={statisticValueStyle("#1890ff")}
              />
              <div style={statisticDescStyle}>
                <div style={dotStyle("#1890ff")} />
                Accumulated training time
              </div>
            </Card>
          </Col>
          <Col xs={24} sm={8}>
            <Card 
              hoverable 
              className="stat-card"
            >
              <Statistic
                title={
                  <div style={statisticTitleStyle("#722ed1")}>
                    <CalendarOutlined style={statisticIconStyle("rgba(114,46,209,0.1)")} />
                    Upcoming Sessions
                  </div>
                }
                value={stats.upcomingAppointments}
                valueStyle={statisticValueStyle("#722ed1")}
              />
              <div style={statisticDescStyle}>
                <div style={dotStyle("#722ed1")} />
                Scheduled training appointments
              </div>
            </Card>
          </Col>
          <Col xs={24} sm={8}>
            <Card 
              hoverable 
              className="stat-card"
            >
              <Statistic
                title={
                  <div style={statisticTitleStyle("#fa8c16")}>
                    <TrophyOutlined style={statisticIconStyle("rgba(250,140,22,0.1)")} />
                    Completed Sessions
                  </div>
                }
                value={stats.completedTrainings}
                valueStyle={statisticValueStyle("#fa8c16")}
              />
              <div style={statisticDescStyle}>
                <div style={dotStyle("#fa8c16")} />
                Finished training sessions
              </div>
            </Card>
          </Col>
        </Row>

        {/* Course Progress Section */}
        {Object.keys(courseProgress).length > 0 && (
          <Row gutter={[24, 24]} style={{ marginBottom: "32px" }}>
            <Col span={24}>
              <Card 
                title={
                  <div style={{ 
                    fontSize: '18px',
                    fontWeight: 600,
                    color: '#1890ff',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px'
                  }}>
                    <TrophyOutlined />
                    Course Progress
                  </div>
                }
              >
                <Row gutter={[24, 24]}>
                  {Object.values(courseProgress).map((progress) => (
                    <Col xs={24} sm={12} key={progress.courseType}>
                      <Card 
                        hoverable 
                        bodyStyle={{ 
                          padding: '20px',
                          background: progress.progressPercentage === 100 ? 'rgba(82,196,26,0.1)' : 'transparent'
                        }}
                      >
                        <div style={{ marginBottom: '12px' }}>
                          <Text strong style={{ fontSize: '16px' }}>
                            {progress.courseType}
                          </Text>
                        </div>
                        <Progress
                          percent={progress.progressPercentage}
                          status={progress.progressPercentage === 100 ? 'success' : 'active'}
                          strokeColor={{
                            '0%': '#108ee9',
                            '100%': progress.progressPercentage === 100 ? '#52c41a' : '#1890ff',
                          }}
                          strokeWidth={10}
                        />
                        <div style={{ 
                          marginTop: '12px',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center'
                        }}>
                          <Text type="secondary">
                            Completed: {progress.completedSessions} / {progress.totalSessionsRequired}
                          </Text>
                          {progress.progressPercentage === 100 && (
                            <Tag color="success" icon={<CheckOutlined />}>
                              Completed
                            </Tag>
                          )}
                        </div>
                      </Card>
                    </Col>
                  ))}
                </Row>
              </Card>
            </Col>
          </Row>
        )}

        {/* Navigation cards */}
        <Row gutter={[24, 24]}>
          <Col xs={24} sm={8}>
            <Link href="/member/appointment" style={{ textDecoration: 'none' }}>
              <Card 
                hoverable 
                className="nav-card nav-card-blue"
              >
                <div style={navCardIconStyle}>
                  <CalendarOutlined />
                </div>
                <Statistic
                  title={
                    <span style={navCardTitleStyle}>
                      Appointment Management
                    </span>
                  }
                  value="Schedule Training"
                  valueStyle={navCardValueStyle}
                />
                <div style={navCardDescStyle}>
                  <div style={navCardDotStyle} />
                  Click to schedule your next session
                </div>
              </Card>
            </Link>
          </Col>
          <Col xs={24} sm={8}>
            <Link href="/member/history" style={{ textDecoration: 'none' }}>
              <Card 
                hoverable 
                className="nav-card nav-card-purple"
              >
                <div style={navCardIconStyle}>
                  <HistoryOutlined />
                </div>
                <Statistic
                  title={
                    <span style={navCardTitleStyle}>
                      Training History
                    </span>
                  }
                  value="View Records"
                  valueStyle={navCardValueStyle}
                />
                <div style={navCardDescStyle}>
                  <div style={navCardDotStyle} />
                  Track your progress
                </div>
              </Card>
            </Link>
          </Col>
          <Col xs={24} sm={8}>
            <Link href="/member/map" style={{ textDecoration: 'none' }}>
              <Card 
                hoverable 
                className="nav-card nav-card-green"
              >
                <div style={navCardIconStyle}>
                  <EnvironmentOutlined />
                </div>
                <Statistic
                  title={
                    <span style={navCardTitleStyle}>
                      Fitness Centers
                    </span>
                  }
                  value="View Map"
                  valueStyle={navCardValueStyle}
                />
                <div style={navCardDescStyle}>
                  <div style={navCardDotStyle} />
                  Find nearby fitness centers
                </div>
              </Card>
            </Link>
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default withAuth(DashboardPage, { requiredRole: 'member' });
